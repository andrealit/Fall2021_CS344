Author: Andrea Tongsak
I submitted the tongsaka_program1.zip through Canvas.
You can compile and run the program with:

gcc --std=gnu99 -o movies main.c
./movies movies_sample_1.csv