Author: Andrea Tongsak
The submission tongsaka_program2.zip is found in Canvas.
To compile and create an executable named movies_by_year:

gcc --std=gnu99 -o movies_by_year main.c
./movies_by_year
