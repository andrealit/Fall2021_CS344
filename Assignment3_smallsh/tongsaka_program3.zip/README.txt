Author: Andrea Tongsak
The submission tongsaka_program3.zip is found in Canvas.
To compile and create an executable named smallsh,

gcc --std=gnu99 -o smallsh main.c
smallsh

To run it with the test script....

Then place the p3testscript in the same directory as smallsh, chmod it.
chmod +x ./p3testscript
and run this command from a bash prompt:
$ ./p3testscript 2>&1
