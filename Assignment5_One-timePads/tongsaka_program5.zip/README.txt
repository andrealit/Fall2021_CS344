This is the submission for OS1 -- Assignment 5: One Time Pads.

The zip file will contain:

keygen.c
enc_server.c
enc_client.c
dec_server.c
dec_client.c
compileall

To create the executables for these scripts, use the compileall script included:

1. Open terminal and navigate into the folder directory (tongsaka_program5)
2. Type compileall to generate the executable files for all the C files
	$ ./compileall
3. Run the p5testscript file with two ports, that should be in the 50000+ range. Every time you run the script, change the port numbers you use!
	$ ./p5testscript RANDOM_PORT1 RANDOM_PORT2

